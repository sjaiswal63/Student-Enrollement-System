package com.example.StudentSpringBootproject.SC;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ScRepository extends JpaRepository<Sc, Long> {

}
