package com.example.StudentSpringBootproject.Payment;

import java.util.List;


public interface PaymentService 
{
	List<Payment> getAllPayments();
	
	Payment savePayment(Payment payment);
	
	Payment getPaymentById(Long paymentid);

}
